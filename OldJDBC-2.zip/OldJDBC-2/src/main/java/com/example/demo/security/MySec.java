package com.example.demo.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;

import com.example.demo.service.HomeService;

@EnableWebSecurity
@Configuration
public class MySec extends WebSecurityConfigurerAdapter{

	@Autowired
	private HomeService mySer;
	
	
	@Bean
	public AuthenticationProvider authProvider()
	{
		DaoAuthenticationProvider dao=new DaoAuthenticationProvider();
		dao.setUserDetailsService(mySer);
		dao.setPasswordEncoder(NoOpPasswordEncoder.getInstance());
		
		return dao;
	}
}
