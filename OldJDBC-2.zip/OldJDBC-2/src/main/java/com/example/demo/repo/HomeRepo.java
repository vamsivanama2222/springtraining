package com.example.demo.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.mapper.UserMapper;
import com.example.demo.model.Appuser;
import com.example.demo.model.MyUser;

@Repository
public class HomeRepo {

	
	@Autowired
	JdbcTemplate template;
	
	@Autowired
	NamedParameterJdbcTemplate namedTemplate;
	
	public String userSelectQuery="select * from app_user";
	
	public String userByNameandPass="select * from app_user where email=?";
	
	
	 public List<com.example.demo.model.Appuser> getAllUserFromDB()
	 { 
		 return template.query(userSelectQuery, new UserMapper());
	 }
	 
	 public Appuser getByEmail(String email)
	 {
		 return template.queryForObject(userByNameandPass, new UserMapper(),email);
	 }
	
	 
}
