$(document).ready(function(){
  loadData();

});
function loadData()
{
	 jQuery.ajax({  
		url: 'http://localhost:8080/getallusersold',  
		type: 'GET',  
		success: function(data) {  
		console.log(data);
					createTable(data);             
				}  
			});  
	
}
function createTable(data)
{
	for(var i=0;i<data.length;i++)
	{
		  $('#mytable tbody').append('<tr><td>'+data[i].name+'</td><td>'+data[i].email+'</td><td>'+data[i].contact+'</td><td><button onclick=deletebutton("'+data[i].email+'")>Delete</button></td></tr>');
	}
}
function deletebutton(email)
{
	console.log(email);
	 jQuery.ajax({  
		url: 'http://localhost:8080/deleteuser?email='+email,
		type: 'DELETE',  
		success: function(data) {  
		console.log(data);
					alert(data);      
					//loadData()	;				
				}  
			});  
}
function submitForm()
{
 
  jQuery.ajax({  
		url: 'http://localhost:8080/insertuser',
		type: 'POST',
		contentType: "application/json",
		data: JSON.stringify({
    "name": $("#tname").val(),
   "email": $("#temail").val(),
   "contact": $("#tcontact").val(),
   "password": $("#tpass").val()
  }),
		success: function(data) {  
		console.log(data);
					alert(data);      			
				}  
			});  
  
  
}

function updateData()
{
	
	var email=$("#upemail").val();
	
	var pass=$("#uppass").val();
	
	 jQuery.ajax({  
		url: 'http://localhost:8080/updateuser?pass='+pass+'&email='+email,
		type: 'PUT',  
		success: function(data) {  
		console.log(data);
					alert(data);      
					//loadData()	;				
				}  
			});  
}