package com.general.Simple.Repository;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.general.Simple.Mapper.UserMapper;
import com.general.Simple.model.*;
@Repository
public class UserRepo  {

	
	@Autowired
	JdbcTemplate template;
	
	@Autowired
	NamedParameterJdbcTemplate namedTemplate;

	public String userSelectQuery="select * from app_user";
	
	public String insertUser="insert into app_user (name,email,contact,password) values(:name,:email,:contact,:password)";
	
	public String updateUser="update app_user set password=:newpassword where email=:email";
	
	public String deleteUser="delete from app_user where email=:email";
	
	 public List<Appuser> getAllUserFromDB()
	 { 
		 return template.query(userSelectQuery, new UserMapper());
	 }
	 
	 public int addUserIntoDB(Appuser user)
	 {
		 MapSqlParameterSource perameter=new MapSqlParameterSource();
		 perameter.addValue("name", user.getName());
		 perameter.addValue("email", user.getEmail());
		 perameter.addValue("contact", user.getContact());
		 perameter.addValue("password", user.getPassword());
		 
		 return namedTemplate.update(insertUser, perameter);
		 
	 }
	 
	 public int updateUserIntoDB(String password,String email)
	 {
		 MapSqlParameterSource perameter=new MapSqlParameterSource();
		 perameter.addValue("newpassword", password);
		 perameter.addValue("email", email);
		 
		 return namedTemplate.update(updateUser, perameter);
		 
	 }
	 
	 public int deleteUserByemail(String email)
	 {
		 MapSqlParameterSource perameter=new MapSqlParameterSource();
		 perameter.addValue("email", email);
		 
		 return namedTemplate.update(deleteUser, perameter);
	 }
	
	
}
