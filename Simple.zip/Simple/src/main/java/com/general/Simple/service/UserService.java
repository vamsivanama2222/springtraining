package com.general.Simple.service;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.general.Simple.Repository.UserRepo;
import com.general.Simple.model.Appuser;
@Service
public class UserService {

	@Autowired
	private UserRepo userRepo;
	
	public List<Appuser> getAllUsers()
	{
		return this.userRepo.getAllUserFromDB();
	}
	
	public int insertData(Appuser user)
	{
		return this.userRepo.addUserIntoDB(user);
	}
	
	public int updateUser(String a,String b)
	{
		return this.userRepo.updateUserIntoDB(a, b);
	}
	 
	public int deleteUser(String email)
	{
		return this.userRepo.deleteUserByemail(email);
	}
}
