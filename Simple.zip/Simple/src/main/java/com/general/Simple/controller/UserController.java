package com.general.Simple.controller;
import java.util.*;
import com.general.Simple.model.*;
import com.general.Simple.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	private UserService userService;

	
	
	
	
	
	
	@GetMapping("/getallusersold")
	public List<Appuser> getAllUsers(){
		return this.userService.getAllUsers();
	}
	
	@GetMapping("/helloworld")
	public String getSample()
	{
		return "hello World";
	}
	
	@PostMapping("/insertuser")
	public String insertData(@RequestBody Appuser user)
	{
		return  "No of rows Inserted "+this.userService.insertData(user);
	}
	
	@PutMapping("/updateuser")
	public String updateData(@RequestParam String pass,@RequestParam String email)
	{
		return "No Of Rows Updated are  "+this.userService.updateUser(pass, email);
	}
	
	@DeleteMapping("/deleteuser")
	public String deleteUser(@RequestParam String email)
	{
		return "No Of Rows deleted are "+this.userService.deleteUser(email);
	}
}
