package com.general.Simple.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
public class Basecontroller {

	@GetMapping("/hello")
	public String getSample()
	{
		return "hello";
	}
}

