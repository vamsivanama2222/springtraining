package com.general.Simple.Mapper;
import com.general.Simple.model.*;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
public class UserMapper  implements RowMapper<Appuser>{

	@Override
	public Appuser mapRow(ResultSet rs, int rowNum) throws SQLException {
		Appuser user = new Appuser();
		user.setId(rs.getInt("u_id"));
		user.setName(rs.getString("name"));
		user.setEmail(rs.getString("email"));
		user.setContact(rs.getLong("contact"));
		user.setPassword(rs.getString("password"));
		return user;
	}

	

}
